.. only:: not (epub or latex or html)

    WARNING: You are looking at unreleased Cilium documentation.
    Please use the official rendered version released here:
    https://docs.cilium.io

###############
Further Reading
###############

.. include:: ../FURTHER_READINGS.rst
      :start-after: further-reading-begin
      :end-before: further-reading-end
